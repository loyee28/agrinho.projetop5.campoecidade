let elementosCidade = [];
let elementosCampo = [];
let xSol;
let ySol;
let direcaoSol = 1; // 1 para indo para a direita, -1 para esquerda
let xVeiculo;
let yVeiculo;
let tipoVeiculo = 'carro'; // 'carro' ou 'boi'

function setup() {
  createCanvas(800, 600);
  xSol = width / 2;
  ySol = 100;
  xVeiculo = 0;
  yVeiculo = height - 50;
  textAlign(CENTER, CENTER);
}

function draw() {
  // Céu
  let corCeuManha = color(135, 206, 235); // Azul claro
  let corCeuNoite = color(25, 25, 112); // Azul escuro
  let proporcaoDia = map(xSol, 0, width, 0, 1);
  let corCeuAtual = lerpColor(corCeuManha, corCeuNoite, proporcaoDia);
  background(corCeuAtual);

  // Sol/Lua
  if (proporcaoDia < 0.5) { // Dia: Sol
    fill(255, 204, 0); // Amarelo
    ellipse(xSol, ySol, 80, 80);
    fill(255, 165, 0, 150); // Laranja claro para o brilho
    ellipse(xSol, ySol, 100, 100);
  } else { // Noite: Lua
    fill(200, 200, 200); // Cinza claro
    ellipse(xSol, ySol, 70, 70);
    fill(150, 150, 150, 100); // Cinza escuro para o brilho
    ellipse(xSol, ySol, 90, 90);
  }

  // Movimento do Sol/Lua
  xSol += 1 * direcaoSol;
  if (xSol > width + 50 || xSol < -50) {
    direcaoSol *= -1; // Inverte a direção
    // Reinicia a posição para simular um ciclo
    xSol = direcaoSol === 1 ? -50 : width + 50;
  }

  // Base da paisagem
  fill(50, 205, 50); // Verde grama
  rect(0, height * 0.7, width, height * 0.3);

  // Linha divisória
  stroke(100);
  strokeWeight(2);
  line(width / 2, height * 0.7, width / 2, height);
  noStroke();

  // Elementos do Campo (lado direito)
  for (let arvore of elementosCampo) {
    desenharArvore(arvore.x, arvore.y);
  }

  // Elementos da Cidade (lado esquerdo)
  for (let predio of elementosCidade) {
    desenharPredio(predio.x, predio.y, predio.h);
  }

  // Veículo (Carro ou Boi)
  desenharVeiculo(xVeiculo, yVeiculo);
  xVeiculo += 2; // Velocidade do veículo
  if (xVeiculo > width + 100) {
    xVeiculo = -100; // Reinicia a posição
    // Alterna o tipo de veículo em cada "passagem"
    tipoVeiculo = (tipoVeiculo === 'carro') ? 'boi' : 'carro';
  }

  // Texto indicativo
  fill(0);
  textSize(20);
  text("Clique para construir!", width / 4, height - 30);
  text("Clique para plantar!", width * 3 / 4, height - 30);
}

function mousePressed() {
  if (mouseY > height * 0.7) { // Só interage na parte de baixo da tela
    if (mouseX < width / 2) { // Lado esquerdo (Cidade)
      let h = random(50, 200);
      elementosCidade.push({
        x: mouseX,
        y: height * 0.7 - h,
        h: h
      });
    } else { // Lado direito (Campo)
      elementosCampo.push({
        x: mouseX,
        y: height * 0.7
      });
    }
  }
}

function desenharArvore(x, y) {
  // Tronco
  fill(139, 69, 19);
  rect(x - 10, y - 50, 20, 50);
  // Folhagem
  fill(34, 139, 34);
  ellipse(x, y - 70, 60, 60);
  ellipse(x - 20, y - 50, 40, 40);
  ellipse(x + 20, y - 50, 40, 40);
}

function desenharPredio(x, y, h) {
  fill(100, 100, 100); // Cinza do prédio
  rect(x - 30, y, 60, h);

  // Janelas
  fill(255, 255, 0); // Amarelo (iluminadas)
  for (let i = 0; i < h; i += 30) {
    rect(x - 20, y + i + 10, 15, 10);
    rect(x + 5, y + i + 10, 15, 10);
  }
}

function desenharVeiculo(x, y) {
  push(); // Salva o estado atual das transformações
  translate(x, y); // Move o sistema de coordenadas para a posição do veículo

  if (tipoVeiculo === 'carro') {
    // Corpo do carro
    fill(255, 0, 0); // Vermelho
    rect(-40, -20, 80, 20); // Base
    rect(-25, -35, 50, 15); // Teto
    // Rodas
    fill(0);
    ellipse(-25, 0, 15, 15);
    ellipse(25, 0, 15, 15);
  } else { // Boi
    fill(139, 69, 19); // Marrom
    // Corpo
    ellipse(0, 0, 60, 40);
    // Cabeça
    ellipse(30, -15, 20, 20);
    // Chifres
    stroke(0);
    strokeWeight(2);
    line(35, -20, 40, -25);
    line(25, -20, 20, -25);
    noStroke();
    // Patas
    rect(-20, 10, 10, 15);
    rect(10, 10, 10, 15);
  }

  pop(); // Restaura o estado salvo
}